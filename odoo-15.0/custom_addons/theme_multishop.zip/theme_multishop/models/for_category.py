# from odoo import api, fields, models, tools, _
#
#
# class ProductPublicCategory(models.Model):
#     _name = "custom.category"
#     _inherit = [
#         'product.public.category']
#     _description ="For Category"

